# pang
Gruppuppgift del 1
SYNED21JON Grupp 6
Medlemmar: Christer Klasson, Ida Gustafsson, Julia Magnusson, Marianne Nordlund, Matti Heinonen, Ronja Österback

Vi har jobbat var för sig och även i live-möten på Teams med denna uppgift. Detta är Christers repo som till slut (förmodligen men inte nödvändigtvis) blir den slutliga.

# Header 1
Test

#Header 2
Test 2
