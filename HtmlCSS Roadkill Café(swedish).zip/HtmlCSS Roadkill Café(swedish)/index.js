/* Gruppuppgift del 1, serverfunktionalitet.
SYNED21JON Grupp 6

Medlemmar:
Christer Klasson 
Ida Gustafsson 
Julia Magnusson 
Marianne Nordlund
Matti Heinonen 
Ronja Österback

Kommentarer:
Vår sidas bokningsformulär tar emot input vid submit och validerar först på
klientsidan. Om allting stämmer så skickas all input till servern där det
sker ytterligare valideringar och hantering av ondskefull input innan det
sparas i en .json-fil.
Vår admin-sidas inloggningsformulär tar emot input vid submit och skickar
direkt till servern för validering och hantering av ondskefull input. Om
inloggningsuppgifterna (som står inskrivna i fälten redan för uppgiftens
enkelhets skull, inte för att någon av oss skulle göra det på en faktisk
sida, lovar!) stämmer så döljs inloggningsformuläret på hemsidan och
bokningarna sparade i .json-filen visas istället. */

// Behöver ha express, kräver express.
const express = require("express");
// FS = FileSystem, låter oss skriva till/från filer.
const fs = require("fs");
// Path = Låter oss skapa en enda path till den publika mappen istället för flera.
const path = require("path");
// Magi som låter oss kolla resultatet av vår validering med express-validator.
const { body, validationResult } = require("express-validator");
// Kollar efter "environment variable" PORT. Hittas ingen används port 3000.
const PORT = process.env.PORT || 3000;

// app använder express.
const app = express();

// Det är här som path drar ihop projektmappen med diverse annat.
app.use(express.static(path.join(__dirname, "publikmapp")));
// Ger express tillgång till input från formulär.
app.use(express.urlencoded({ extended: false }));
// Skapar en ny array som kommer hjälpa oss att skriva till/från .json-filen.
let bokningsArray = new Array();

// Läser in formulärdata som skickas från klientskriptet.
app.post(
  "/request",
  body("antal").isNumeric().withMessage("Inmatning är inte en siffra"),
  body("epost") // Antal gäster hanteras i HTML.
    .isEmail()
    .withMessage("Inmatning är inte en giltig e-postadress"),
  (req, res) => {
    /* Tar emot data från klientskriptets objekt och sparar i egna variabler
    (dvs. skapar ett nytt objekt här på servern). */
    const nyBokning = {
      inkom: req.body.inkom,
      datum_received: req.body.datum,
      antal_received: req.body.antal,
      tid_received: req.body.tid,
      namn_received: escape(req.body.namn),
      epost_received: escape(req.body.epost),
      meddelande_received: escape(req.body.meddelande),
    };

    console.log(nyBokning);

    // Läser in data från .json-fil och sparar i JSON-format i variabel.
    const dataTagetUrFil = fs.readFileSync("bokningar.json");

    /* Skriver över arrayen med data från .json-fil efter konvertering från JSON-format
    (string) till JS-objekt. Förhindrar att data i filen skrivs över med nollställd
    array varenda gång servern startas om. */
    bokningsArray = JSON.parse(dataTagetUrFil);

    const validering_resultat = validationResult(req);

    // Validering sker.
    if (!validering_resultat.isEmpty()) {
      let valideringError = "";

      validering_resultat.array().forEach((error) => {
        valideringError += "\n" + error.msg;
      });

      console.log(valideringError);
    } else {
      // Det nya objektet läggs till i arrayen.
      bokningsArray.push(nyBokning);

      // Arrayen konverteras från JS-objekt till JSON-format och skrivs in i .json-fil.
      fs.writeFile(
        "bokningar.json",
        JSON.stringify(bokningsArray, null, 2),
        (err) => {
          if (err) throw err;
          console.log("En ny bokning har lagts till");
        }
      );
    }
  }
);

// Länkar vår "route" för admin-sidans innehåll till vår main index.js / resten av sidan.
app.use("/admin", require("./routes/adminWebsite"));
app.listen(PORT, () => console.log(`Server started on port ${PORT}`));
