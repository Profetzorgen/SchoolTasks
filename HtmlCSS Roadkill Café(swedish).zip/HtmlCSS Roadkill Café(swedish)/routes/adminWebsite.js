const express = require("express");
const fs = require("fs");
const { escape } = require("querystring");
// Som app = express i index.js fast router = express istället!
const router = express.Router();

router.use(express.urlencoded({ extended: false }));

/* Vi skriver bara "/" här med då det är underförstått att vi menar /admin
eftersom vi specificerade det näst längst ner i index.js när vi länkade till
den här routen. */
router.get("/", (req, res) => {
  res.sendFile("admin.html", { root: "./publikmapp" });
});

/* Administratörens inloggningsuppgifter som ligger väldigt luftigt och okrypterat,
men det får vara med tanke på att sidan ändå inte ska sättas i bruk. */
const adminInlogg = {
  username: "PangAdmin",
  password: "PangAdmin8",
};

// router = app. Eftersom detta skript är routat till index.js får app namnet router, mer info längst ner vid den koden.
// Vi gjorde såhär då det är mer överskådligt att ha en egen fil med bara admin-relaterat innehåll.
router.post("/", (req, res) => {
  // Tar emot formuläret direkt utan klientskript-mellanhand vid submit.
  const mottagnaFormVar = {
    username: escape(req.body.username),
    password: escape(req.body.password),
  };

  // Kollar om användarnamnet stämmer.
  if (mottagnaFormVar.username !== adminInlogg.username) {
    console.log("Misslyckad inloggning: Användaren finns inte.");

    // Byter ut texten på adminsidan mot fel-texten.
    fs.readFile("./publikmapp/admin.html", (err, data) => {
      const felHTML1 = data
        .toString()
        .replace(
          "Logga in för att se bokningar.",
          "Misslyckad inloggning: Användaren finns inte."
        );
      res.send(felHTML1);
    });
  }
  // Kollar om lösenordet matchar användarnamnet.
  else if (
    mottagnaFormVar.username === adminInlogg.username &&
    mottagnaFormVar.password !== adminInlogg.password
  ) {
    console.log(
      "Misslyckad inloggning: Användarnamn och lösenord överensstämmer inte."
    );

    // Byter ut texten på adminsidan mot fel-texten.
    fs.readFile("./publikmapp/admin.html", (err, data) => {
      const felHTML2 = data
        .toString()
        .replace(
          "Logga in för att se bokningar.",
          "Misslyckad inloggning: Användarnamn och lösenord överensstämmer inte."
        );
      res.send(felHTML2);
    });
    // Inget utslag än? Allting matchade! I choose you, ELSE!
  } else {
    // Dvs: när inget är fel med admin/pass: läs in från bokningar.json
    const bokningarFultFormat = JSON.parse(fs.readFileSync("bokningar.json"));
    let bokningarSnyggtFormat = "";

    // Gör om arrayen med bokningsinfo till en något mer stilfull sådan.
    bokningarSnyggtFormat += `<tr><th>Inkom</th><th>Valt datum</th><th>Antal</th>
      <th>Vald tid</th><th>Namn</th><th>E-post</th>
      <th>Meddelande</th></tr>`;
    for (let y = bokningarFultFormat.length-1; y >=0; y--) {
      bokningarSnyggtFormat += `
        <tr><td>${bokningarFultFormat[y].inkom}</td>
        <td>${bokningarFultFormat[y].datum_received}</td>
        <td>${bokningarFultFormat[y].antal_received}</td>
        <td>${bokningarFultFormat[y].tid_received}</td>
        <td>${unescape(bokningarFultFormat[y].namn_received)}</td>
        <td>${unescape(bokningarFultFormat[y].epost_received)}</td>
        <td>${unescape(bokningarFultFormat[y].meddelande_received)}</td>
        </tr>`;
    }

    // Lägger till den friserade bokningsinformationen till adminsidan.
    fs.readFile("./publikmapp/admin.html", (err, data) => {
      const nyHTML1 = data
        .toString()
        .replace("Logga in för att se bokningar.", bokningarSnyggtFormat);
      const nyHTML2 = nyHTML1.replace("noClassHere", "hidden");
      res.send(nyHTML2);
    });
  }
});

// Detta gör att denna fil räknas som en förlängning av index.js dvs. serverskriptet.
module.exports = router;
